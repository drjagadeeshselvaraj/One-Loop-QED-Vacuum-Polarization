Elsevier (elsarticle) version of the paper.
Compile with XeLaTeX (needs elsarticle, fontspec, TeX Gyre Termes): xelatex Regulator_Independence_elsarticle.tex  (run twice)
Class options: preprint,12pt. Set \journal{...} and change to review/final/3p as the target journal requires.
