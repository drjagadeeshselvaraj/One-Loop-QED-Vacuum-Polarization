"""Regenerates Figures 2-5 of the paper from the closed forms and from the saved reference outputs.
Run in this directory:  python3 make_figures.py   (needs numpy, scipy, matplotlib, mpmath)."""
import re, numpy as np, mpmath as mp, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','mathtext.fontset':'dejavuserif','font.size':9,'axes.linewidth':.8,'figure.dpi':100})
BL,RD,GR='#1f4e9c','#c0392b','#2e8b57'
mp.mp.dps=30
alpha=mp.mpf(1)/mp.mpf('137.036'); m=mp.mpf('0.511')*mp.mpf('1e-3')   # GeV (as in the paper)
def PiR(Q2,mm=m):
    return 2*alpha/mp.pi*mp.quad(lambda x:x*(1-x)*mp.log(1+Q2*x*(1-x)/mm**2),[0,.5,1])
def Pi_pv(Q2,Ms,cs):   # Pi_R-type integrand plus regulator terms, sum c_i = -1
    return 2*alpha/mp.pi*mp.quad(lambda x:x*(1-x)*(mp.log(1+Q2*x*(1-x)/m**2)+sum(c*mp.log(1+Q2*x*(1-x)/M**2) for c,M in zip(cs,Ms))),[0,.5,1])
def Pi_pt(Q2,L):
    f=lambda x:x*(1-x)*(mp.e1(m**2/L**2)-mp.e1((m**2+Q2*x*(1-x))/L**2))
    return 2*alpha/mp.pi*mp.quad(f,[0,.5,1])
# ---------- Figure 2: orders of convergence at Q^2 = 0.01 GeV^2
Q2=mp.mpf('0.01'); ref=PiR(Q2)
Ls=np.logspace(0,3,10)
def err(fn): return [abs(float(fn(mp.mpf(L))-ref)) for L in Ls]
e_pt=err(lambda L:Pi_pt(Q2,L))
e_pv=err(lambda L:Pi_pv(Q2,[L],[-1]))
e_ex=err(lambda L:(4*Pi_pt(Q2,2*L)-Pi_pt(Q2,L))/3)
e_im=err(lambda L:Pi_pv(Q2,[L,2*L],[mp.mpf(1)/3,-mp.mpf(4)/3]))
print('check single PV M=10:',float(Pi_pv(Q2,[10],[-1])-ref),' improved PV 10,20:',float(Pi_pv(Q2,[10,20],[mp.mpf(1)/3,-mp.mpf(4)/3])-ref))
fig,ax=plt.subplots(figsize=(5.6,3.5))
ax.loglog(Ls,e_pv,'x',color=RD,label='single Pauli–Villars ($\\Lambda^{-2}$)')
ax.loglog(Ls,e_pt,'o',mfc='none',color=BL,label='proper-time cutoff ($\\Lambda^{-2}$)')
ax.loglog(Ls,e_ex,'s',mfc='none',color=GR,label='two-point extrapolation ($\\Lambda^{-4}$)')
ax.loglog(Ls,e_im,'^',mfc='none',color='k',label='improved weights $1/3,-4/3$ ($\\Lambda^{-4}$)')
ax.set_xlabel('regulator scale $\\Lambda$ (GeV)'); ax.set_ylabel('$|\\Pi_{\\rm reg}-\\Pi_R|$'); ax.grid(True,which='both',alpha=.25); ax.legend(frameon=False,fontsize=8)
fig.tight_layout(); fig.savefig('figures/fig2_orders.png',dpi=300); plt.close(fig)
# ---------- Figure 3: running of Pi_R for leptons
ml={'e':mp.mpf('0.51099895e-3'),'μ':mp.mpf('0.1056583755'),'τ':mp.mpf('1.77686')}
Qs=np.logspace(-2,3,60); fig,ax=plt.subplots(figsize=(5.6,3.5))
tot=np.zeros(len(Qs))
for (n,mm),c in zip(ml.items(),[BL,RD,GR]):
    v=np.array([float(PiR(mp.mpf(Q)**2,mm)) for Q in Qs]); tot+=v
    ax.loglog(Qs,v,color=c,lw=1,label=f'{n} loop')
ax.loglog(Qs,tot,'k',lw=1.6,label='sum of e, μ, τ')
MZ=91.1876; tz=sum(float(PiR(mp.mpf(MZ)**2,mm)) for mm in ml.values())
ax.plot([MZ],[tz],'ko',ms=4); ax.annotate(f'$Q=M_Z$: $\\Pi_R={tz:.5f}$',(MZ,tz),xytext=(-150,28),textcoords='offset points',fontsize=8,arrowprops=dict(arrowstyle='-',lw=.6))
print('leptonic Pi_R at Q=MZ:',tz)
ax.set_xlabel('$Q$ (GeV)'); ax.set_ylabel('$\\Pi_R(Q^2)$'); ax.grid(True,which='both',alpha=.25); ax.legend(frameon=False,fontsize=8,loc='lower right')
fig.tight_layout(); fig.savefig('figures/fig3_running.png',dpi=300); plt.close(fig)
# ---------- Figure 4: two-loop diagram-level test against Kallen-Sabry
txt=open('twoloop_results_output.txt').read()
secs=re.split(r'\n## ',txt)[1:]
data={}
for s in secs:
    name=s.split('\n')[0].strip(); mm=re.match(r'(out[A-Z]*Q?\d*|out)_L(\d+)\.txt',name)
    if not mm: continue
    two=re.search(r'two-loop\s+Pi2 = (-?[\d.]+)\s+target ([\d.]+)',s)
    if two: data.setdefault(mm.group(1),{})[int(mm.group(2))]=(abs(float(two.group(1))),float(two.group(2)))
print({k:sorted(v) for k,v in data.items()})
KS={4.0:0.62821652018414,0.5:0.11704351288357}
fig,axs=plt.subplots(1,2,figsize=(6.4,3.2),sharey=True)
for ax,(Q2k,sets,ttl) in zip(axs,[(4.0,[('out','single PV',BL,'o'),('outD','double PV',RD,'x'),('outG','Gaussian',GR,'s')],'$Q^2=4$'),(0.5,[('outQ05','single PV',BL,'o'),('outGQ05','Gaussian',GR,'s')],'$Q^2=0.5$')]):
    for key,lab,c,mk in sets:
        d=data.get(key,{}); L=sorted(d)
        if not L: continue
        ax.loglog(L,[abs(d[l][0]/KS[Q2k]-1) for l in L],mk,mfc='none' if mk!='x' else c,color=c,label=lab)
    import matplotlib.ticker as mt
    ax.set_xticks([4,8,16,32,64,128,256,512] if Q2k==4.0 else [32,64,128,256,512]); ax.get_xaxis().set_major_formatter(mt.ScalarFormatter()); ax.xaxis.set_minor_formatter(mt.NullFormatter()); ax.tick_params(axis='x',labelsize=7)
    ax.set_title(ttl,fontsize=9); ax.set_xlabel('photon regulator scale $\\Lambda$ (units of $m$)'); ax.grid(True,which='both',alpha=.25); ax.legend(frameon=False,fontsize=8)
axs[0].set_ylabel('$|\\Pi^{(2)}_{\\rm computed}/\\Pi^{(2)}_{\\rm KS}-1|$')
fig.tight_layout(); fig.savefig('figures/fig4_twoloop.png',dpi=300); plt.close(fig)
# ---------- Figure 5: sharp outer cutoff (control)
rows=[l.split() for l in open('sharp_control_output.txt') if re.match(r'\s+\d+\s',l)]
R=np.array([float(r[0]) for r in rows]); p1=np.array([float(r[2]) for r in rows]); p2=np.array([float(r[4]) for r in rows])
fig,ax=plt.subplots(figsize=(5.6,3.3))
ax.semilogx(R,p1,'o-',mfc='none',color=BL,lw=.8,label='one loop, $\\Pi_L^{(1)}/R^2$')
ax.semilogx(R,p2,'s-',mfc='none',color=RD,lw=.8,label='two loop, $\\Pi_L^{(2)}/R^2$')
ax.axhline(-.5,color='k',ls='--',lw=.8); ax.text(1.05,-.45,'$-1/2$',fontsize=8)
ax.set_xlabel('sharp outer cutoff $R$ (units of $m$)'); ax.set_ylabel('longitudinal part $/R^2$'); ax.grid(True,which='both',alpha=.25); ax.legend(frameon=False,fontsize=8)
fig.tight_layout(); fig.savefig('figures/fig5_sharp_control.png',dpi=300); plt.close(fig)
